package com.PSL.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PSL.demo.Entities.Book;
import com.PSL.demo.Service.BookService;

@RestController
@RequestMapping(value="/book")
public class BookController {
	
	@Autowired
	BookService bookservice;
	
	@GetMapping(value="/getalldetails",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Book> getalldetails() {
		
		return bookservice.FindallDetails();
	}
	
	@PostMapping(value="/PostBookData",consumes=MediaType.APPLICATION_JSON_VALUE)
	public Book saveBookdata(@RequestBody Book book) {
		
		return bookservice.PostBookdata(book);
	}
	
	@DeleteMapping(value="/deleteBookdata",consumes=MediaType.APPLICATION_JSON_VALUE)
	public void deletebookdata(@RequestBody Book book) {
		
		bookservice.DeleteData(book);	
		
	}
	
	@PutMapping(value="/updateBook/{id}",consumes=MediaType.APPLICATION_JSON_VALUE)
	public Book UpdateBookdata(@PathVariable int id,@RequestBody Book book) {
		
		return bookservice.UpdateData(id,book);
	}

}
