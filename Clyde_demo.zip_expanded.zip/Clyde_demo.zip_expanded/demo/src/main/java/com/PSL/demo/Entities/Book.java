package com.PSL.demo.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
@Entity
public class Book {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int BookId;
	private String BookName;
	private String BookAuthorname;
	private String BookDomainname;
	private String BookPrice;
	
	public Book() {
		
		super();
	}
	
	public Book(int bookId, String bookName, String bookAuthorname, String bookDomainname, String bookPrice) {
		super();
		BookId = bookId;
		BookName = bookName;
		BookAuthorname = bookAuthorname;
		BookDomainname = bookDomainname;
		BookPrice = bookPrice;
	}
	public int getBookId() {
		return BookId;
	}
	public void setBookId(int bookId) {
		BookId = bookId;
	}
	public String getBookName() {
		return BookName;
	}
	public void setBookName(String bookName) {
		BookName = bookName;
	}
	public String getBookAuthorname() {
		return BookAuthorname;
	}
	public void setBookAuthorname(String bookAuthorname) {
		BookAuthorname = bookAuthorname;
	}
	public String getBookDomainname() {
		return BookDomainname;
	}
	public void setBookDomainname(String bookDomainname) {
		BookDomainname = bookDomainname;
	}
	public String getBookPrice() {
		return BookPrice;
	}
	public void setBookPrice(String bookPrice) {
		BookPrice = bookPrice;
	}
	
	

}
