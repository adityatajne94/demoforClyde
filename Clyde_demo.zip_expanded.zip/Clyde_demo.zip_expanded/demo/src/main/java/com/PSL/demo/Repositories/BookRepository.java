package com.PSL.demo.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.PSL.demo.Entities.Book;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {

}
