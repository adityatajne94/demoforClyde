package com.PSL.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PSL.demo.Entities.Book;
import com.PSL.demo.Repositories.BookRepository;

@Service
public class BookService{
	
	@Autowired
	BookRepository bookrepo;
	
	public List<Book> FindallDetails() {
		
		return bookrepo.findAll();
	}
	
	public Book PostBookdata(Book book) {
		
		return bookrepo.save(book);
	}
	
	public void DeleteData(Book book) {
		
		bookrepo.delete(book); 
		
	}
	public Book UpdateData(int id,Book book) {
		
		Optional<Book> bookentity = bookrepo.findById(id);
		Book bookupdate = bookentity.get();
		
		bookupdate.setBookId(book.getBookId());
		bookupdate.setBookName(book.getBookName());
		bookupdate.setBookAuthorname(book.getBookAuthorname());
		bookupdate.setBookDomainname(book.getBookDomainname());
		bookupdate.setBookPrice(book.getBookPrice());
		
		return bookrepo.save(bookupdate);
	}

}
